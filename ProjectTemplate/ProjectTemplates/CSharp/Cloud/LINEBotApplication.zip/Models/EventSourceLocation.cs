using Microsoft.WindowsAzure.Storage.Table;

namespace $safeprojectname$.Models
{
    public class EventSourceLocation : EventSourceState
    {
        public string Location { get; set; }

        public EventSourceLocation() { }
    }
}