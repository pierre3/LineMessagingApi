﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace $projectname$
{
    public class BlobStorage
    {
        private CloudBlobClient _blobClient;
        private CloudBlobContainer _blobContainer;

        public BlobStorage(string connectionString)
        {
            var strageAccount = CloudStorageAccount.Parse(connectionString);
            _blobClient = strageAccount.CreateCloudBlobClient();
        }

        public static async Task<BlobStorage> CreateAsync(string connectionString, string containerName)
        {
            var instance = new BlobStorage(connectionString);
            await instance.InitializeAsync(containerName);
            return instance;
        }

        public async Task InitializeAsync(string containerName)
        {
            _blobContainer = _blobClient.GetContainerReference(containerName);
            await _blobContainer.CreateIfNotExistsAsync();
            _blobContainer.SetPermissions(
                new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });
        }

        public async Task<Uri> UploadImageAsync(System.Drawing.Image image, string directoryName, string blobName)
        {
            var directory = _blobContainer.GetDirectoryReference(directoryName);
            var blob = directory.GetBlockBlobReference(blobName);
            using (var stream = new MemoryStream())
            {
                image.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
                stream.Position = 0;
                await blob.UploadFromStreamAsync(stream);
                return blob.Uri;
            }
        }

        public async Task<Uri> UploadFromStreamAsync(Stream stream, string directoryName, string blobName)
        {
            var directory = _blobContainer.GetDirectoryReference(directoryName);
            var blob = directory.GetBlockBlobReference(blobName);
            await blob.UploadFromStreamAsync(stream);
            return blob.Uri;
        }

        public async Task DeleteImageAsync(string directoryName, string blobName)
        {
            var directory = _blobContainer.GetDirectoryReference(directoryName);
            var blob = directory.GetBlockBlobReference(blobName);
            await blob.DeleteIfExistsAsync();
        }

        public async Task DeleteDirectoryAsync(string directoryName)
        {
            var directory = _blobContainer.GetDirectoryReference(directoryName);
            foreach (CloudBlob blob in directory.ListBlobs())
            {
                await blob.DeleteIfExistsAsync();
            }
        }

        public IEnumerable<Uri> ListBlobUri(string directoryName)
        {
            var directory = _blobContainer.GetDirectoryReference(directoryName);
            return directory.ListBlobs().Select(blob => blob.Uri);
        }
    }
}

