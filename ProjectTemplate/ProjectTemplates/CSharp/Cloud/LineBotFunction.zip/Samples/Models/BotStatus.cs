﻿using Microsoft.WindowsAzure.Storage.Table;

namespace $projectname$
{
    public class BotStatus : EventSourceState
    {
        public string Location { get; set; }
        public string CurrentApp { get; set; }

        public BotStatus() { }
    }
}
