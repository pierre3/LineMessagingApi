#!/bin/bash

BASE="$(cd "$(dirname "$0")"; pwd)"
source "$BASE/common.sh"

bundle exec fastlane doc