# LINE SDK v5.11 for iOS Swift

Developed in Swift, the LINE SDK for iOS Swift provides a modern way of implementing LINE APIs. The features included in this SDK will help you develop an iOS app with engaging and personalized user experience.
